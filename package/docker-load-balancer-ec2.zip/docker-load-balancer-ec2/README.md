# docker-load-balancer-ec2
A complete guide on deploying a Docker Swarm load balancer on local machine and multi-node Amazon EC2 instances
